import React from 'react';
import { Sidebar } from './components/Sidebar';
import { WorkspaceContent } from './components/WorkspaceContent';
import { useWorkspace } from './hooks/useWorkspace';

function App() {
  const { activeWorkspace, workspaces, switchWorkspace } = useWorkspace();
  const currentWorkspace = workspaces.find((w) => w.id === activeWorkspace)!;

  return (
    <div className="flex h-screen bg-gray-50">
      <Sidebar
        workspaces={workspaces}
        activeWorkspace={activeWorkspace}
        onWorkspaceSwitch={switchWorkspace}
      />
      <main className="flex-1 overflow-auto">
        <WorkspaceContent workspace={currentWorkspace} />
      </main>
    </div>
  );
}

export default App;