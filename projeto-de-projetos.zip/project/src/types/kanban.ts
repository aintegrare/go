export interface KanbanCard {
  id: string;
  title: string;
  description: string;
  status: string;
  createdAt: string;
}

export interface KanbanColumn {
  id: string;
  title: string;
  cards: KanbanCard[];
}