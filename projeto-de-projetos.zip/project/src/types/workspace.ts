export interface Workspace {
  id: string;
  name: string;
  icon: string;
  color?: string;
}

export interface WorkspaceState {
  activeWorkspace: string;
  workspaces: Workspace[];
}