import { useState, useCallback } from 'react';
import { Workspace } from '../types/workspace';

export function useWorkspace() {
  const [activeWorkspace, setActiveWorkspace] = useState<string>('personal');
  const [workspaces] = useState<Workspace[]>([
    { id: 'personal', name: 'Personal', icon: 'user' },
    { id: 'work', name: 'Work', icon: 'briefcase' },
    { id: 'projects', name: 'Projects', icon: 'folder' },
  ]);

  const switchWorkspace = useCallback((workspaceId: string) => {
    setActiveWorkspace(workspaceId);
  }, []);

  return {
    activeWorkspace,
    workspaces,
    switchWorkspace,
  };
}