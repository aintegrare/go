import { useState, useCallback } from 'react';
import { KanbanCard, KanbanColumn } from '../types/kanban';

export function useKanban() {
  const [columns] = useState<KanbanColumn[]>([
    {
      id: 'todo',
      title: 'To Do',
      cards: [
        {
          id: '1',
          title: 'Research competitors',
          description: 'Analyze main competitors and their features',
          status: 'todo',
          createdAt: '2024-03-15',
        },
        {
          id: '2',
          title: 'Design system',
          description: 'Create a consistent design system',
          status: 'todo',
          createdAt: '2024-03-16',
        },
      ],
    },
    {
      id: 'in-progress',
      title: 'In Progress',
      cards: [
        {
          id: '3',
          title: 'User authentication',
          description: 'Implement user authentication flow',
          status: 'in-progress',
          createdAt: '2024-03-14',
        },
      ],
    },
    {
      id: 'done',
      title: 'Done',
      cards: [
        {
          id: '4',
          title: 'Project setup',
          description: 'Initial project setup and configuration',
          status: 'done',
          createdAt: '2024-03-13',
        },
      ],
    },
  ]);

  const [activeColumn, setActiveColumn] = useState(columns[0].id);
  const [selectedCard, setSelectedCard] = useState<KanbanCard | null>(null);

  const switchColumn = useCallback((columnId: string) => {
    setActiveColumn(columnId);
    setSelectedCard(null);
  }, []);

  return {
    columns,
    activeColumn,
    selectedCard,
    switchColumn,
    setSelectedCard,
  };
}