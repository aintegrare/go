import React from 'react';
import { Layers, User, Briefcase, Folder } from 'lucide-react';
import { Workspace } from '../types/workspace';

interface SidebarProps {
  workspaces: Workspace[];
  activeWorkspace: string;
  onWorkspaceSwitch: (id: string) => void;
}

const iconMap = {
  user: User,
  briefcase: Briefcase,
  folder: Folder,
};

export function Sidebar({ workspaces, activeWorkspace, onWorkspaceSwitch }: SidebarProps) {
  return (
    <div className="w-64 bg-white h-full border-r border-gray-200 p-4">
      <div className="flex items-center mb-8">
        <Layers className="h-6 w-6 text-indigo-600" />
        <h1 className="text-xl font-semibold ml-2">Workspaces</h1>
      </div>
      
      <nav>
        {workspaces.map((workspace) => {
          const IconComponent = iconMap[workspace.icon as keyof typeof iconMap];
          return (
            <button
              key={workspace.id}
              onClick={() => onWorkspaceSwitch(workspace.id)}
              className={`w-full flex items-center p-3 rounded-lg mb-2 transition-colors ${
                activeWorkspace === workspace.id
                  ? 'bg-indigo-50 text-indigo-600'
                  : 'hover:bg-gray-50 text-gray-700'
              }`}
            >
              <IconComponent className="h-5 w-5" />
              <span className="ml-3 font-medium">{workspace.name}</span>
            </button>
          );
        })}
      </nav>
    </div>
  );
}