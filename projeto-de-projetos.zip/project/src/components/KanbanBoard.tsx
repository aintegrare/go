import React from 'react';
import { KanbanColumn } from './KanbanColumn';
import { KanbanCardDetail } from './KanbanCardDetail';
import { useKanban } from '../hooks/useKanban';

export function KanbanBoard() {
  const { columns, activeColumn, selectedCard, switchColumn, setSelectedCard } = useKanban();
  const currentColumn = columns.find((col) => col.id === activeColumn)!;

  return (
    <div className="flex h-full">
      <div className={`flex-1 flex flex-col ${selectedCard ? 'lg:w-1/2' : 'w-full'}`}>
        <div className="border-b border-gray-200 bg-white">
          <div className="flex space-x-1 p-4">
            {columns.map((column) => (
              <button
                key={column.id}
                onClick={() => switchColumn(column.id)}
                className={`px-4 py-2 text-sm font-medium rounded-lg transition-colors
                  ${activeColumn === column.id
                    ? 'bg-indigo-100 text-indigo-700'
                    : 'text-gray-500 hover:bg-gray-100'
                  }`}
              >
                {column.title}
                <span className="ml-2 bg-gray-100 text-gray-600 px-2 py-1 rounded-full text-xs">
                  {column.cards.length}
                </span>
              </button>
            ))}
          </div>
        </div>
        
        <KanbanColumn
          column={currentColumn}
          onCardSelect={setSelectedCard}
        />
      </div>

      {selectedCard && (
        <div className="hidden lg:block w-1/2 border-l border-gray-200">
          <KanbanCardDetail
            card={selectedCard}
            onClose={() => setSelectedCard(null)}
          />
        </div>
      )}
    </div>
  );
}