import React from 'react';
import { KanbanCard, KanbanColumn as IKanbanColumn } from '../types/kanban';

interface KanbanColumnProps {
  column: IKanbanColumn;
  onCardSelect: (card: KanbanCard) => void;
}

export function KanbanColumn({ column, onCardSelect }: KanbanColumnProps) {
  return (
    <div className="flex-1 overflow-auto p-4 bg-gray-50">
      <div className="grid gap-4">
        {column.cards.map((card) => (
          <button
            key={card.id}
            onClick={() => onCardSelect(card)}
            className="w-full text-left bg-white p-4 rounded-lg shadow-sm border border-gray-200 
              hover:shadow-md transition-shadow"
          >
            <h3 className="text-lg font-semibold text-gray-900">{card.title}</h3>
            <p className="mt-1 text-gray-600 line-clamp-2">{card.description}</p>
            <div className="mt-4 text-xs text-gray-500">
              Created: {new Date(card.createdAt).toLocaleDateString()}
            </div>
          </button>
        ))}
      </div>
    </div>
  );
}