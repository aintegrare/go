import React from 'react';
import { User, Briefcase, Folder } from 'lucide-react';
import { Workspace } from '../types/workspace';

interface WorkspaceContentProps {
  workspace: Workspace;
}

const iconMap = {
  user: User,
  briefcase: Briefcase,
  folder: Folder,
};

export function WorkspaceContent({ workspace }: WorkspaceContentProps) {
  const IconComponent = iconMap[workspace.icon as keyof typeof iconMap];

  return (
    <div className="p-8">
      <div className="flex items-center mb-6">
        <IconComponent className="h-8 w-8 text-indigo-600" />
        <h2 className="text-2xl font-bold ml-3">{workspace.name} Workspace</h2>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {[1, 2, 3].map((item) => (
          <div
            key={item}
            className="bg-white p-6 rounded-lg shadow-sm border border-gray-200 hover:shadow-md transition-shadow"
          >
            <h3 className="text-lg font-semibold mb-2">Sample Card {item}</h3>
            <p className="text-gray-600">
              This is a placeholder card for the {workspace.name} workspace.
            </p>
          </div>
        ))}
      </div>
    </div>
  );
}